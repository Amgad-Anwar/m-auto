<?php
get_template_part( 'template-parts/cars/single-car/car-summary' );
