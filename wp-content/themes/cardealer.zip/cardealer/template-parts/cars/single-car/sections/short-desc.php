<?php
the_excerpt();
cardealer_car_price_html( 'aside-price hide-sell hide-status' );
