<?php
cardealer_get_cars_details_breadcrumb();
?>
<h1 class="car-title"><?php the_title(); ?></h1>
<?php
cardealer_subtitle_attributes( get_the_ID() );
