<?php
cardealer_get_vehicle_review_stamps( get_the_ID() );
