<?php
/**
 * Admin init file
 *
 * @package Cardealer
 * @version 1.0.0
 */

/**
 * Include file
 */
get_template_part( 'includes/admin/class', 'cardealer-theme-activation' );
get_template_part( 'includes/admin/theme-panel/cardealer', 'panel' );
