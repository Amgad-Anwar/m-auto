<?php
/**
 * Welcome Content file
 *
 * @package Cardealer
 */

?>
<h2><?php echo esc_html__( 'Congratulations! Theme activated successfully.', 'cardealer' ); ?></h2>
<p><?php echo wp_kses( __( '<strong>Car Dealer</strong> is an elegant, clean, beautiful and best responsive WordPress theme.', 'cardealer' ), array( 'strong' => array() ) ); ?></p>
<div class="important">
	<p><em><?php echo wp_kses( __( '<strong>Car Dealer</strong> contains many usefull features and functionalities. And, it requires some plugins to be pre-installed to enable all inbuilt features and functionalities.', 'cardealer' ), array( 'strong' => array() ) ); ?></em></p>
</div>
